The program need a tuple with all the accounts with the next structure and order:
[First Name, Last Name, Account Number, Amount of money in the account, Empty List, Empty List]
Has to be in that order
The program validate that the ammounts of money are integer and greater than 0
The login process:
    Account number has max 3 attempts
    Password has no amount of limit
The code has comments all over to help understand and guide
The program transform the tuple to a list with the accounts
The program before ends return the list to a Tuple